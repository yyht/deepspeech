This package provides TensorFlow kernels that wrap the WarpCTC
library.  Kernels are provided for both the CTCLoss op already in
TensorFlow, as well as a new WarpCTC op provided in this package.  The
WarpCTC op has an interface that more closely matches the native
WarpCTC interface than TensorFlow's CTCLoss op. Note that the CTCLoss
op expects the reserved blank label to be the largest value while the
WarpCTC op takes the reserved blank label value as an attribute which
defaults to `0`.

